import imp  #test load path

import json
print(JavaClass)

val = JavaClass("from python")
val.callback(1234.4564)
val.callback("sdfsdfsdfsdf")
val.SetPythonObject(json);
print("===========end=========")